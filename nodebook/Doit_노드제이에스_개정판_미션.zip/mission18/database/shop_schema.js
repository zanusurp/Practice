/**
 * Shop 스키마
 * 
 */

var Schema = {};

Schema.createSchema = function(mongoose) {
	
	// 스키마 정의
	var ShopSchema = mongoose.Schema({
	    name: {type: String, index: 'hashed', 'default':''},
	    address: {type: String, 'default':''},
	    tel: {type: String, 'default':''},
        shop_type: {type: String, 'default':''},
	    geometry: {
	    	'type': {type: String, 'default': "Point"},
	    	coordinates: [{type: "Number"}]
	    },
	    created_at: {type: Date, index: {unique: false}, 'default': Date.now},
	    updated_at: {type: Date, index: {unique: false}, 'default': Date.now}
	});
	
	ShopSchema.index({geometry:'2dsphere'});

	// 스키마에 static 메소드 추가
	// 모든 커피숍 조회
	ShopSchema.static('findAll', function(callback) {
		return this.find({}, callback);
	});
	
	// 가장 가까운 커피숍 조회
	ShopSchema.static('findNear', function(longitude, latitude, maxDistance, callback) {
		console.log('ShopSchema의 findNear 호출됨.');

		this.find().where('geometry').near({center:{type:'Point', coordinates:[parseFloat(longitude), parseFloat(latitude)]}, maxDistance:maxDistance}).limit(1).exec(callback);
	});
	
	// 일정 범위 내의 커피숍 조회
	ShopSchema.static('findWithin', function(topleft_longitude, topleft_latitude, bottomright_longitude, bottomright_latitude, callback) {
		console.log('ShopSchema의 findWithin 호출됨.');

		this.find().where('geometry').within({box:[[parseFloat(topleft_longitude), parseFloat(topleft_latitude)], [parseFloat(bottomright_longitude), parseFloat(bottomright_latitude)]]}).exec(callback);
	});
	
	// 일정 반경 내의 커피숍 조회
	ShopSchema.static('findCircle', function(shop_type, center_longitude, center_latitude, radius, callback) {
		console.log('ShopSchema의 findCircle 호출됨.');
		
		// change radian : 1/6371 -> 1km
		this.find()
            .where('shop_type').equals(shop_type)
            .where('geometry').within({center:[parseFloat(center_longitude), parseFloat(center_latitude)], radius: parseFloat(radius/6371000), unique: true, spherical: true}).exec(callback);
	});
	
	console.log('ShopSchema 정의함.');

	return ShopSchema;
};

// module.exports에 Schema 객체 직접 할당
module.exports = Schema;

