# TensorFlow.js Example: Getting Started

This minimal example loads tfjs from a CDN, builds and trains a minimal model,
and uses it to predict.  Edit `index.js` and load `index.html` in your
browser to test small snippets.
