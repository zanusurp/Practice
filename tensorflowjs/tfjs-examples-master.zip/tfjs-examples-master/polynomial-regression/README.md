# TensorFlow.js Example: Polynomial Regression

This example creates a synthetic polynomial dataset and fits the polynomial
curve using the layers API.

[See this example live!](https://storage.googleapis.com/tfjs-examples/polynomial-regression/dist/index.html)
