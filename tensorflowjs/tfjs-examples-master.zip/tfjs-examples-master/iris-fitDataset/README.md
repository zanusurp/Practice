# TensorFlow.js Example: Iris Classification using tfjs-data APIs

This example is identical to the
[iris](https://github.com/tensorflow/tfjs-examples/tree/master/iris) example,
except that it uses the [tfjs-data](https://github.com/tensorflow/tfjs-data)
APIs.

Please see the
[iris](https://github.com/tensorflow/tfjs-examples/tree/master/iris) example for
details and how to run.
